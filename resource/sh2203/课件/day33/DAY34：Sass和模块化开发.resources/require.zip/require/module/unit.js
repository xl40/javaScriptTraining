define(function(){

	return {
		colorRange :[1, 2, 3, 4, 5, 6, 7, 8, 9, "A", "B", "C", "D", "E", "F"],
		randomColor:function(){

			return {
            	color: "#" + this.colorRange[Math.floor(Math.random() * 15)] + this.colorRange[Math.floor(Math.random() * 15)] + this.colorRange[Math.floor(Math.random() * 15)] + this.colorRange[Math.floor(Math.random() * 15)] + this.colorRange[Math.floor(Math.random() * 15)] + this.colorRange[Math.floor(Math.random() * 15)]
        	}
		}
	}

})